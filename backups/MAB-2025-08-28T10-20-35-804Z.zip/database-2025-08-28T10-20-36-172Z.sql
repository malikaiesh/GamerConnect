--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (84ade85)
-- Dumped by pg_dump version 16.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS neondb;
--
-- Name: neondb; Type: DATABASE; Schema: -; Owner: neondb_owner
--

CREATE DATABASE neondb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE neondb OWNER TO neondb_owner;

\connect neondb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ad_position; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.ad_position AS ENUM (
    'above_featured',
    'below_featured',
    'above_popular',
    'below_popular',
    'above_about',
    'below_about'
);


ALTER TYPE public.ad_position OWNER TO neondb_owner;

--
-- Name: api_key_type; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.api_key_type AS ENUM (
    'tinymce',
    'game-monetize',
    'analytics',
    'sendgrid',
    'custom'
);


ALTER TYPE public.api_key_type OWNER TO neondb_owner;

--
-- Name: backup_status; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.backup_status AS ENUM (
    'pending',
    'in_progress',
    'completed',
    'failed',
    'cancelled'
);


ALTER TYPE public.backup_status OWNER TO neondb_owner;

--
-- Name: backup_storage; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.backup_storage AS ENUM (
    'local',
    'cloud',
    'both'
);


ALTER TYPE public.backup_storage OWNER TO neondb_owner;

--
-- Name: backup_type; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.backup_type AS ENUM (
    'full',
    'database_only',
    'files_only',
    'settings_only'
);


ALTER TYPE public.backup_type OWNER TO neondb_owner;

--
-- Name: blog_status; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.blog_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.blog_status OWNER TO neondb_owner;

--
-- Name: content_status; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.content_status AS ENUM (
    'active',
    'inactive'
);


ALTER TYPE public.content_status OWNER TO neondb_owner;

--
-- Name: event_location_type; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.event_location_type AS ENUM (
    'online',
    'physical',
    'hybrid'
);


ALTER TYPE public.event_location_type OWNER TO neondb_owner;

--
-- Name: event_status; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.event_status AS ENUM (
    'draft',
    'published',
    'ongoing',
    'completed',
    'cancelled'
);


ALTER TYPE public.event_status OWNER TO neondb_owner;

--
-- Name: event_type; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.event_type AS ENUM (
    'tournament',
    'game_release',
    'community',
    'maintenance',
    'seasonal',
    'streaming',
    'meetup',
    'competition',
    'other'
);


ALTER TYPE public.event_type OWNER TO neondb_owner;

--
-- Name: game_ad_position; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.game_ad_position AS ENUM (
    'above_game',
    'below_game',
    'above_related',
    'below_related',
    'sidebar_top',
    'sidebar_bottom'
);


ALTER TYPE public.game_ad_position OWNER TO neondb_owner;

--
-- Name: game_file_type; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.game_file_type AS ENUM (
    'html5',
    'apk',
    'ios',
    'unity'
);


ALTER TYPE public.game_file_type OWNER TO neondb_owner;

--
-- Name: game_source; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.game_source AS ENUM (
    'api',
    'custom'
);


ALTER TYPE public.game_source OWNER TO neondb_owner;

--
-- Name: game_status; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.game_status AS ENUM (
    'active',
    'inactive',
    'featured'
);


ALTER TYPE public.game_status OWNER TO neondb_owner;

--
-- Name: notification_type; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.notification_type AS ENUM (
    'alert',
    'banner',
    'modal',
    'slide-in',
    'toast',
    'web-push',
    'survey'
);


ALTER TYPE public.notification_type OWNER TO neondb_owner;

--
-- Name: page_type; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.page_type AS ENUM (
    'about',
    'contact',
    'privacy',
    'terms',
    'cookie-policy',
    'faq',
    'custom'
);


ALTER TYPE public.page_type OWNER TO neondb_owner;

--
-- Name: registration_status; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.registration_status AS ENUM (
    'registered',
    'cancelled',
    'attended',
    'no_show'
);


ALTER TYPE public.registration_status OWNER TO neondb_owner;

--
-- Name: restore_status; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.restore_status AS ENUM (
    'pending',
    'in_progress',
    'completed',
    'failed',
    'cancelled'
);


ALTER TYPE public.restore_status OWNER TO neondb_owner;

--
-- Name: schema_content_type; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.schema_content_type AS ENUM (
    'game',
    'blog_post',
    'page',
    'category',
    'organization',
    'global'
);


ALTER TYPE public.schema_content_type OWNER TO neondb_owner;

--
-- Name: schema_type; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.schema_type AS ENUM (
    'VideoGame',
    'Article',
    'BlogPosting',
    'Organization',
    'WebPage',
    'AboutPage',
    'ContactPage',
    'FAQPage',
    'CollectionPage',
    'BreadcrumbList',
    'Review',
    'Rating',
    'Product',
    'Person'
);


ALTER TYPE public.schema_type OWNER TO neondb_owner;

--
-- Name: session_status; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.session_status AS ENUM (
    'active',
    'expired',
    'revoked'
);


ALTER TYPE public.session_status OWNER TO neondb_owner;

--
-- Name: signup_provider; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.signup_provider AS ENUM (
    'email',
    'google',
    'facebook',
    'github',
    'discord',
    'twitter',
    'apple',
    'microsoft',
    'phone'
);


ALTER TYPE public.signup_provider OWNER TO neondb_owner;

--
-- Name: sitemap_type; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.sitemap_type AS ENUM (
    'games',
    'blog',
    'pages',
    'main'
);


ALTER TYPE public.sitemap_type OWNER TO neondb_owner;

--
-- Name: token_type; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.token_type AS ENUM (
    'password_reset',
    'email_verification',
    'admin_reset'
);


ALTER TYPE public.token_type OWNER TO neondb_owner;

--
-- Name: user_account_type; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.user_account_type AS ENUM (
    'local',
    'google',
    'facebook',
    'github',
    'discord',
    'twitter',
    'apple',
    'microsoft',
    'phone'
);


ALTER TYPE public.user_account_type OWNER TO neondb_owner;

--
-- Name: user_status; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.user_status AS ENUM (
    'active',
    'blocked'
);


ALTER TYPE public.user_status OWNER TO neondb_owner;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_activity_logs; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.admin_activity_logs (
    id integer NOT NULL,
    user_id integer NOT NULL,
    action text NOT NULL,
    entity_type text,
    entity_id integer,
    description text NOT NULL,
    ip_address text,
    user_agent text,
    metadata json,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_activity_logs OWNER TO neondb_owner;

--
-- Name: admin_activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.admin_activity_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_activity_logs_id_seq OWNER TO neondb_owner;

--
-- Name: admin_activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.admin_activity_logs_id_seq OWNED BY public.admin_activity_logs.id;


--
-- Name: admin_notifications; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.admin_notifications (
    id integer NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    icon text DEFAULT 'ri-notification-line'::text,
    priority text DEFAULT 'medium'::text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    action_url text,
    related_entity_type text,
    related_entity_id integer,
    user_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_notifications OWNER TO neondb_owner;

--
-- Name: admin_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.admin_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_notifications_id_seq OWNER TO neondb_owner;

--
-- Name: admin_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.admin_notifications_id_seq OWNED BY public.admin_notifications.id;


--
-- Name: analytics; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.analytics (
    id integer NOT NULL,
    date timestamp without time zone DEFAULT now() NOT NULL,
    page_views integer DEFAULT 0 NOT NULL,
    unique_visitors integer DEFAULT 0 NOT NULL,
    game_play_count integer DEFAULT 0 NOT NULL,
    average_session_duration integer DEFAULT 0 NOT NULL,
    top_games json DEFAULT '{}'::json NOT NULL,
    top_pages json DEFAULT '{}'::json NOT NULL
);


ALTER TABLE public.analytics OWNER TO neondb_owner;

--
-- Name: analytics_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.analytics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.analytics_id_seq OWNER TO neondb_owner;

--
-- Name: analytics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.analytics_id_seq OWNED BY public.analytics.id;


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    name text NOT NULL,
    type public.api_key_type NOT NULL,
    key text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.api_keys OWNER TO neondb_owner;

--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_keys_id_seq OWNER TO neondb_owner;

--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: backup_configs; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.backup_configs (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    backup_type public.backup_type DEFAULT 'full'::public.backup_type NOT NULL,
    storage_location public.backup_storage DEFAULT 'local'::public.backup_storage NOT NULL,
    cloud_storage_path text,
    schedule text,
    is_schedule_enabled boolean DEFAULT false NOT NULL,
    retention_days integer DEFAULT 30 NOT NULL,
    max_backups integer DEFAULT 10 NOT NULL,
    include_database_structure boolean DEFAULT true NOT NULL,
    include_database_data boolean DEFAULT true NOT NULL,
    include_uploads boolean DEFAULT true NOT NULL,
    include_assets boolean DEFAULT true NOT NULL,
    include_settings boolean DEFAULT true NOT NULL,
    include_logs boolean DEFAULT false NOT NULL,
    compression_enabled boolean DEFAULT true NOT NULL,
    compression_level integer DEFAULT 6 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.backup_configs OWNER TO neondb_owner;

--
-- Name: backup_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.backup_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_configs_id_seq OWNER TO neondb_owner;

--
-- Name: backup_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.backup_configs_id_seq OWNED BY public.backup_configs.id;


--
-- Name: backup_files; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.backup_files (
    id integer NOT NULL,
    backup_id integer NOT NULL,
    file_path text NOT NULL,
    file_name text NOT NULL,
    file_type text NOT NULL,
    file_size integer,
    checksum_md5 text,
    last_modified timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.backup_files OWNER TO neondb_owner;

--
-- Name: backup_files_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.backup_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_files_id_seq OWNER TO neondb_owner;

--
-- Name: backup_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.backup_files_id_seq OWNED BY public.backup_files.id;


--
-- Name: backup_logs; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.backup_logs (
    id integer NOT NULL,
    backup_id integer,
    restore_id integer,
    operation text NOT NULL,
    level text DEFAULT 'info'::text NOT NULL,
    message text NOT NULL,
    details json,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.backup_logs OWNER TO neondb_owner;

--
-- Name: backup_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.backup_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_logs_id_seq OWNER TO neondb_owner;

--
-- Name: backup_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.backup_logs_id_seq OWNED BY public.backup_logs.id;


--
-- Name: backups; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.backups (
    id integer NOT NULL,
    config_id integer,
    name text NOT NULL,
    description text,
    backup_type public.backup_type NOT NULL,
    status public.backup_status DEFAULT 'pending'::public.backup_status NOT NULL,
    file_name text,
    file_path text,
    cloud_storage_path text,
    file_size integer,
    checksum_md5 text,
    checksum_sha256 text,
    database_table_count integer,
    total_records integer,
    file_count integer,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    duration integer,
    error_message text,
    warning_message text,
    metadata json,
    triggered_by text DEFAULT 'manual'::text NOT NULL,
    created_by integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.backups OWNER TO neondb_owner;

--
-- Name: backups_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.backups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backups_id_seq OWNER TO neondb_owner;

--
-- Name: backups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.backups_id_seq OWNED BY public.backups.id;


--
-- Name: blog_categories; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.blog_categories (
    id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.blog_categories OWNER TO neondb_owner;

--
-- Name: blog_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.blog_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_categories_id_seq OWNER TO neondb_owner;

--
-- Name: blog_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.blog_categories_id_seq OWNED BY public.blog_categories.id;


--
-- Name: blog_posts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.blog_posts (
    id integer NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    content text NOT NULL,
    excerpt text NOT NULL,
    featured_image text NOT NULL,
    category_id integer,
    tags text[],
    status public.blog_status DEFAULT 'draft'::public.blog_status NOT NULL,
    author text NOT NULL,
    author_avatar text,
    published_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.blog_posts OWNER TO neondb_owner;

--
-- Name: blog_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.blog_posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_posts_id_seq OWNER TO neondb_owner;

--
-- Name: blog_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.blog_posts_id_seq OWNED BY public.blog_posts.id;


--
-- Name: event_categories; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.event_categories (
    id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    color text DEFAULT '#6366f1'::text,
    icon text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.event_categories OWNER TO neondb_owner;

--
-- Name: event_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.event_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.event_categories_id_seq OWNER TO neondb_owner;

--
-- Name: event_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.event_categories_id_seq OWNED BY public.event_categories.id;


--
-- Name: event_category_relations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.event_category_relations (
    id integer NOT NULL,
    event_id integer NOT NULL,
    category_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.event_category_relations OWNER TO neondb_owner;

--
-- Name: event_category_relations_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.event_category_relations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.event_category_relations_id_seq OWNER TO neondb_owner;

--
-- Name: event_category_relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.event_category_relations_id_seq OWNED BY public.event_category_relations.id;


--
-- Name: event_registrations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.event_registrations (
    id integer NOT NULL,
    event_id integer NOT NULL,
    user_id integer,
    guest_name text,
    guest_email text,
    guest_phone text,
    status public.registration_status DEFAULT 'registered'::public.registration_status NOT NULL,
    notes text,
    payment_status text DEFAULT 'pending'::text,
    registered_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.event_registrations OWNER TO neondb_owner;

--
-- Name: event_registrations_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.event_registrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.event_registrations_id_seq OWNER TO neondb_owner;

--
-- Name: event_registrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.event_registrations_id_seq OWNED BY public.event_registrations.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.events (
    id integer NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    description text NOT NULL,
    event_type public.event_type NOT NULL,
    status public.event_status DEFAULT 'draft'::public.event_status NOT NULL,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone,
    timezone text DEFAULT 'UTC'::text NOT NULL,
    location_type public.event_location_type NOT NULL,
    location_name text,
    location_address text,
    online_url text,
    registration_enabled boolean DEFAULT false NOT NULL,
    registration_start_date timestamp without time zone,
    registration_end_date timestamp without time zone,
    max_participants integer,
    current_participants integer DEFAULT 0 NOT NULL,
    registration_fee integer DEFAULT 0 NOT NULL,
    banner_image text,
    gallery json DEFAULT '[]'::json,
    rules text,
    prizes text,
    requirements text,
    contact_info text,
    meta_title text,
    meta_description text,
    featured boolean DEFAULT false NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.events OWNER TO neondb_owner;

--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.events_id_seq OWNER TO neondb_owner;

--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.id;


--
-- Name: game_ads; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.game_ads (
    id integer NOT NULL,
    name text NOT NULL,
    "position" public.game_ad_position NOT NULL,
    ad_code text NOT NULL,
    status public.content_status DEFAULT 'active'::public.content_status NOT NULL,
    image_url text,
    target_url text,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    is_google_ad boolean DEFAULT false NOT NULL,
    ad_enabled boolean DEFAULT true NOT NULL,
    click_count integer DEFAULT 0 NOT NULL,
    impression_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.game_ads OWNER TO neondb_owner;

--
-- Name: game_ads_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.game_ads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.game_ads_id_seq OWNER TO neondb_owner;

--
-- Name: game_ads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.game_ads_id_seq OWNED BY public.game_ads.id;


--
-- Name: game_categories; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.game_categories (
    id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    icon text DEFAULT 'ri-gamepad-line'::text,
    display_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.game_categories OWNER TO neondb_owner;

--
-- Name: game_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.game_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.game_categories_id_seq OWNER TO neondb_owner;

--
-- Name: game_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.game_categories_id_seq OWNED BY public.game_categories.id;


--
-- Name: games; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.games (
    id integer NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    description text NOT NULL,
    thumbnail text NOT NULL,
    url text,
    api_id text,
    category text NOT NULL,
    category_id integer,
    tags text[] NOT NULL,
    source public.game_source NOT NULL,
    status public.game_status DEFAULT 'active'::public.game_status NOT NULL,
    plays integer DEFAULT 0 NOT NULL,
    rating_sum integer DEFAULT 0 NOT NULL,
    rating_count integer DEFAULT 0 NOT NULL,
    file_type public.game_file_type,
    file_path text,
    file_size integer,
    orientation text DEFAULT 'landscape'::text,
    instructions text,
    screenshot1 text,
    screenshot2 text,
    screenshot3 text,
    screenshot4 text,
    app_store_url text,
    play_store_url text,
    amazon_app_store_url text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.games OWNER TO neondb_owner;

--
-- Name: games_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.games_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.games_id_seq OWNER TO neondb_owner;

--
-- Name: games_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.games_id_seq OWNED BY public.games.id;


--
-- Name: hero_images; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.hero_images (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    image_path text NOT NULL,
    link_url text,
    link_text text,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    display_duration integer DEFAULT 5000 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.hero_images OWNER TO neondb_owner;

--
-- Name: hero_images_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.hero_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hero_images_id_seq OWNER TO neondb_owner;

--
-- Name: hero_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.hero_images_id_seq OWNED BY public.hero_images.id;


--
-- Name: home_ads; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.home_ads (
    id integer NOT NULL,
    name text NOT NULL,
    "position" public.ad_position NOT NULL,
    ad_code text NOT NULL,
    status public.content_status DEFAULT 'active'::public.content_status NOT NULL,
    image_url text,
    target_url text,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    is_google_ad boolean DEFAULT false NOT NULL,
    ad_enabled boolean DEFAULT true NOT NULL,
    click_count integer DEFAULT 0 NOT NULL,
    impression_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.home_ads OWNER TO neondb_owner;

--
-- Name: home_ads_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.home_ads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.home_ads_id_seq OWNER TO neondb_owner;

--
-- Name: home_ads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.home_ads_id_seq OWNED BY public.home_ads.id;


--
-- Name: homepage_content; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.homepage_content (
    id integer NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    status public.content_status DEFAULT 'active'::public.content_status NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.homepage_content OWNER TO neondb_owner;

--
-- Name: homepage_content_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.homepage_content_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.homepage_content_id_seq OWNER TO neondb_owner;

--
-- Name: homepage_content_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.homepage_content_id_seq OWNED BY public.homepage_content.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.password_reset_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token text NOT NULL,
    token_hash text NOT NULL,
    type public.token_type DEFAULT 'password_reset'::public.token_type NOT NULL,
    used_at timestamp without time zone,
    ip_address text,
    user_agent text,
    is_admin boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone NOT NULL
);


ALTER TABLE public.password_reset_tokens OWNER TO neondb_owner;

--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.password_reset_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.password_reset_tokens_id_seq OWNER TO neondb_owner;

--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.password_reset_tokens_id_seq OWNED BY public.password_reset_tokens.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    resource text NOT NULL,
    action text NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.permissions OWNER TO neondb_owner;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.permissions_id_seq OWNER TO neondb_owner;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: push_campaigns; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.push_campaigns (
    id integer NOT NULL,
    name text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    image text,
    link text,
    action_yes text,
    action_no text,
    notification_type text DEFAULT 'toast'::text NOT NULL,
    is_web_push boolean DEFAULT false NOT NULL,
    require_interaction boolean DEFAULT false,
    badge text,
    icon text,
    vibrate text,
    is_survey boolean DEFAULT false,
    target_all boolean DEFAULT true,
    target_filters json DEFAULT '{}'::json,
    sent_count integer DEFAULT 0,
    delivered_count integer DEFAULT 0,
    click_count integer DEFAULT 0,
    schedule_date timestamp without time zone,
    status text DEFAULT 'draft'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.push_campaigns OWNER TO neondb_owner;

--
-- Name: push_campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.push_campaigns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.push_campaigns_id_seq OWNER TO neondb_owner;

--
-- Name: push_campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.push_campaigns_id_seq OWNED BY public.push_campaigns.id;


--
-- Name: push_notifications; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.push_notifications (
    id integer NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    image text,
    link text,
    type public.notification_type DEFAULT 'toast'::public.notification_type NOT NULL,
    active boolean DEFAULT false NOT NULL,
    click_count integer DEFAULT 0 NOT NULL,
    impression_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.push_notifications OWNER TO neondb_owner;

--
-- Name: push_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.push_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.push_notifications_id_seq OWNER TO neondb_owner;

--
-- Name: push_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.push_notifications_id_seq OWNED BY public.push_notifications.id;


--
-- Name: push_responses; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.push_responses (
    id integer NOT NULL,
    campaign_id integer NOT NULL,
    subscriber_id integer NOT NULL,
    response text,
    clicked boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.push_responses OWNER TO neondb_owner;

--
-- Name: push_responses_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.push_responses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.push_responses_id_seq OWNER TO neondb_owner;

--
-- Name: push_responses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.push_responses_id_seq OWNED BY public.push_responses.id;


--
-- Name: push_subscribers; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.push_subscribers (
    id integer NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    user_agent text,
    browser text,
    os text,
    device_type text,
    country text,
    region text,
    city text,
    last_sent timestamp without time zone,
    status text DEFAULT 'active'::text NOT NULL,
    web_push_enabled boolean DEFAULT true NOT NULL,
    notification_permission text DEFAULT 'default'::text,
    preferred_types text[] DEFAULT '{toast,web-push}'::text[],
    frequency_limit integer DEFAULT 5,
    opt_in_date timestamp without time zone DEFAULT now(),
    last_interacted timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.push_subscribers OWNER TO neondb_owner;

--
-- Name: push_subscribers_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.push_subscribers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.push_subscribers_id_seq OWNER TO neondb_owner;

--
-- Name: push_subscribers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.push_subscribers_id_seq OWNED BY public.push_subscribers.id;


--
-- Name: ratings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.ratings (
    id integer NOT NULL,
    game_id integer NOT NULL,
    rating integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ratings OWNER TO neondb_owner;

--
-- Name: ratings_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.ratings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ratings_id_seq OWNER TO neondb_owner;

--
-- Name: ratings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.ratings_id_seq OWNED BY public.ratings.id;


--
-- Name: restores; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.restores (
    id integer NOT NULL,
    backup_id integer NOT NULL,
    name text NOT NULL,
    description text,
    status public.restore_status DEFAULT 'pending'::public.restore_status NOT NULL,
    restore_database boolean DEFAULT true NOT NULL,
    restore_files boolean DEFAULT true NOT NULL,
    restore_settings boolean DEFAULT true NOT NULL,
    create_backup_before_restore boolean DEFAULT true NOT NULL,
    pre_restore_backup_id integer,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    duration integer,
    total_steps integer,
    completed_steps integer,
    current_step text,
    tables_restored integer,
    records_restored integer,
    files_restored integer,
    error_message text,
    warning_message text,
    metadata json,
    created_by integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.restores OWNER TO neondb_owner;

--
-- Name: restores_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.restores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.restores_id_seq OWNER TO neondb_owner;

--
-- Name: restores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.restores_id_seq OWNED BY public.restores.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.role_permissions (
    id integer NOT NULL,
    role_id integer NOT NULL,
    permission_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO neondb_owner;

--
-- Name: role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.role_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.role_permissions_id_seq OWNER TO neondb_owner;

--
-- Name: role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.role_permissions_id_seq OWNED BY public.role_permissions.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.roles OWNER TO neondb_owner;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO neondb_owner;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: seo_schema_analytics; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.seo_schema_analytics (
    id integer NOT NULL,
    schema_id integer NOT NULL,
    date timestamp without time zone DEFAULT now() NOT NULL,
    impressions integer DEFAULT 0 NOT NULL,
    clicks integer DEFAULT 0 NOT NULL,
    avg_position integer,
    rich_snippet_appearances integer DEFAULT 0 NOT NULL,
    validation_status text DEFAULT 'valid'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.seo_schema_analytics OWNER TO neondb_owner;

--
-- Name: seo_schema_analytics_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.seo_schema_analytics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seo_schema_analytics_id_seq OWNER TO neondb_owner;

--
-- Name: seo_schema_analytics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.seo_schema_analytics_id_seq OWNED BY public.seo_schema_analytics.id;


--
-- Name: seo_schema_templates; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.seo_schema_templates (
    id integer NOT NULL,
    name text NOT NULL,
    schema_type public.schema_type NOT NULL,
    content_type public.schema_content_type NOT NULL,
    template json NOT NULL,
    description text,
    is_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by integer NOT NULL,
    updated_by integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.seo_schema_templates OWNER TO neondb_owner;

--
-- Name: seo_schema_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.seo_schema_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seo_schema_templates_id_seq OWNER TO neondb_owner;

--
-- Name: seo_schema_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.seo_schema_templates_id_seq OWNED BY public.seo_schema_templates.id;


--
-- Name: seo_schemas; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.seo_schemas (
    id integer NOT NULL,
    schema_type public.schema_type NOT NULL,
    content_type public.schema_content_type NOT NULL,
    content_id integer,
    name text NOT NULL,
    schema_data json NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_auto_generated boolean DEFAULT true NOT NULL,
    last_validated timestamp without time zone,
    validation_errors json,
    priority integer DEFAULT 0 NOT NULL,
    created_by integer NOT NULL,
    updated_by integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.seo_schemas OWNER TO neondb_owner;

--
-- Name: seo_schemas_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.seo_schemas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seo_schemas_id_seq OWNER TO neondb_owner;

--
-- Name: seo_schemas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.seo_schemas_id_seq OWNED BY public.seo_schemas.id;


--
-- Name: session; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.session OWNER TO neondb_owner;

--
-- Name: signup_options; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.signup_options (
    id integer NOT NULL,
    provider public.signup_provider NOT NULL,
    display_name text NOT NULL,
    is_enabled boolean DEFAULT false NOT NULL,
    icon text NOT NULL,
    color text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    configuration json,
    description text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.signup_options OWNER TO neondb_owner;

--
-- Name: signup_options_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.signup_options_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.signup_options_id_seq OWNER TO neondb_owner;

--
-- Name: signup_options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.signup_options_id_seq OWNED BY public.signup_options.id;


--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.site_settings (
    id integer NOT NULL,
    site_title text NOT NULL,
    meta_description text NOT NULL,
    keywords text NOT NULL,
    site_logo text,
    site_favicon text,
    use_text_logo boolean DEFAULT true,
    text_logo_color text DEFAULT '#4f46e5'::text,
    current_theme text DEFAULT 'modern'::text NOT NULL,
    ads_txt text,
    footer_copyright text,
    footer_app_store_link text,
    footer_google_play_link text,
    footer_amazon_link text,
    social_facebook text,
    social_twitter text,
    social_instagram text,
    social_youtube text,
    social_discord text,
    social_whatsapp text,
    social_tiktok text,
    header_ads text,
    footer_ads text,
    sidebar_ads text,
    content_ads text,
    floating_header_ads text,
    floating_footer_ads text,
    paragraph2_ad text,
    paragraph4_ad text,
    paragraph6_ad text,
    paragraph8_ad text,
    after_content_ad text,
    enable_google_ads boolean DEFAULT false,
    google_ad_client text,
    push_notifications_enabled boolean DEFAULT true NOT NULL,
    blog_games_enabled boolean DEFAULT true NOT NULL,
    paragraph2_games_enabled boolean DEFAULT true NOT NULL,
    paragraph6_games_enabled boolean DEFAULT true NOT NULL,
    paragraph8_games_enabled boolean DEFAULT true NOT NULL,
    paragraph10_games_enabled boolean DEFAULT true NOT NULL,
    custom_header_code text,
    custom_body_code text,
    custom_footer_code text,
    robots_txt text,
    cookie_popup_enabled boolean DEFAULT true NOT NULL,
    cookie_popup_title text DEFAULT 'We use cookies'::text NOT NULL,
    cookie_popup_message text DEFAULT 'We use cookies to improve your experience on our website. By browsing this website, you agree to our use of cookies.'::text NOT NULL,
    cookie_accept_button_text text DEFAULT 'Accept All'::text NOT NULL,
    cookie_decline_button_text text DEFAULT 'Decline'::text NOT NULL,
    cookie_learn_more_text text DEFAULT 'Learn More'::text NOT NULL,
    cookie_learn_more_url text DEFAULT '/privacy'::text NOT NULL,
    cookie_popup_position text DEFAULT 'bottom'::text NOT NULL,
    cookie_popup_theme text DEFAULT 'dark'::text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.site_settings OWNER TO neondb_owner;

--
-- Name: site_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.site_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.site_settings_id_seq OWNER TO neondb_owner;

--
-- Name: site_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.site_settings_id_seq OWNED BY public.site_settings.id;


--
-- Name: sitemaps; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.sitemaps (
    id integer NOT NULL,
    type public.sitemap_type NOT NULL,
    last_generated timestamp without time zone DEFAULT now() NOT NULL,
    url text NOT NULL,
    item_count integer DEFAULT 0 NOT NULL,
    content text,
    is_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sitemaps OWNER TO neondb_owner;

--
-- Name: sitemaps_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.sitemaps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sitemaps_id_seq OWNER TO neondb_owner;

--
-- Name: sitemaps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.sitemaps_id_seq OWNED BY public.sitemaps.id;


--
-- Name: static_pages; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.static_pages (
    id integer NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    content text NOT NULL,
    page_type public.page_type NOT NULL,
    meta_title text,
    meta_description text,
    status public.content_status DEFAULT 'active'::public.content_status NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.static_pages OWNER TO neondb_owner;

--
-- Name: static_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.static_pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.static_pages_id_seq OWNER TO neondb_owner;

--
-- Name: static_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.static_pages_id_seq OWNED BY public.static_pages.id;


--
-- Name: team_members; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.team_members (
    id integer NOT NULL,
    name text NOT NULL,
    designation text NOT NULL,
    profile_picture text,
    bio text,
    social_linkedin text,
    social_twitter text,
    social_github text,
    social_instagram text,
    social_tiktok text,
    social_facebook text,
    social_youtube text,
    display_order integer DEFAULT 0 NOT NULL,
    status public.content_status DEFAULT 'active'::public.content_status NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.team_members OWNER TO neondb_owner;

--
-- Name: team_members_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.team_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.team_members_id_seq OWNER TO neondb_owner;

--
-- Name: team_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.team_members_id_seq OWNED BY public.team_members.id;


--
-- Name: url_redirects; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.url_redirects (
    id integer NOT NULL,
    source_url text NOT NULL,
    target_url text NOT NULL,
    status_code integer DEFAULT 301 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.url_redirects OWNER TO neondb_owner;

--
-- Name: url_redirects_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.url_redirects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.url_redirects_id_seq OWNER TO neondb_owner;

--
-- Name: url_redirects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.url_redirects_id_seq OWNED BY public.url_redirects.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.user_sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token text NOT NULL,
    ip_address text,
    user_agent text,
    device_info json,
    last_activity timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    status public.session_status DEFAULT 'active'::public.session_status NOT NULL,
    location json,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_sessions OWNER TO neondb_owner;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_sessions_id_seq OWNER TO neondb_owner;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    email text,
    password text,
    is_admin boolean DEFAULT false NOT NULL,
    role_id integer,
    display_name text,
    profile_picture text,
    bio text,
    country text,
    account_type public.user_account_type DEFAULT 'local'::public.user_account_type NOT NULL,
    social_id text,
    status public.user_status DEFAULT 'active'::public.user_status NOT NULL,
    last_login timestamp without time zone,
    location json,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: website_update_history; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.website_update_history (
    id integer NOT NULL,
    update_id integer NOT NULL,
    version text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    change_type text NOT NULL,
    priority text NOT NULL,
    status text NOT NULL,
    github_commit_hash text,
    deployment_url text,
    rollback_data json,
    is_active boolean DEFAULT false NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.website_update_history OWNER TO neondb_owner;

--
-- Name: website_update_history_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.website_update_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.website_update_history_id_seq OWNER TO neondb_owner;

--
-- Name: website_update_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.website_update_history_id_seq OWNED BY public.website_update_history.id;


--
-- Name: website_updates; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.website_updates (
    id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    version text NOT NULL,
    change_type text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    deployment_url text,
    github_commit_hash text,
    scheduled_at timestamp without time zone,
    deployed_at timestamp without time zone,
    created_by integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.website_updates OWNER TO neondb_owner;

--
-- Name: website_updates_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.website_updates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.website_updates_id_seq OWNER TO neondb_owner;

--
-- Name: website_updates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.website_updates_id_seq OWNED BY public.website_updates.id;


--
-- Name: admin_activity_logs id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.admin_activity_logs ALTER COLUMN id SET DEFAULT nextval('public.admin_activity_logs_id_seq'::regclass);


--
-- Name: admin_notifications id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.admin_notifications ALTER COLUMN id SET DEFAULT nextval('public.admin_notifications_id_seq'::regclass);


--
-- Name: analytics id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.analytics ALTER COLUMN id SET DEFAULT nextval('public.analytics_id_seq'::regclass);


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: backup_configs id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.backup_configs ALTER COLUMN id SET DEFAULT nextval('public.backup_configs_id_seq'::regclass);


--
-- Name: backup_files id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.backup_files ALTER COLUMN id SET DEFAULT nextval('public.backup_files_id_seq'::regclass);


--
-- Name: backup_logs id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.backup_logs ALTER COLUMN id SET DEFAULT nextval('public.backup_logs_id_seq'::regclass);


--
-- Name: backups id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.backups ALTER COLUMN id SET DEFAULT nextval('public.backups_id_seq'::regclass);


--
-- Name: blog_categories id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_categories ALTER COLUMN id SET DEFAULT nextval('public.blog_categories_id_seq'::regclass);


--
-- Name: blog_posts id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_posts ALTER COLUMN id SET DEFAULT nextval('public.blog_posts_id_seq'::regclass);


--
-- Name: event_categories id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.event_categories ALTER COLUMN id SET DEFAULT nextval('public.event_categories_id_seq'::regclass);


--
-- Name: event_category_relations id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.event_category_relations ALTER COLUMN id SET DEFAULT nextval('public.event_category_relations_id_seq'::regclass);


--
-- Name: event_registrations id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.event_registrations ALTER COLUMN id SET DEFAULT nextval('public.event_registrations_id_seq'::regclass);


--
-- Name: events id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: game_ads id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.game_ads ALTER COLUMN id SET DEFAULT nextval('public.game_ads_id_seq'::regclass);


--
-- Name: game_categories id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.game_categories ALTER COLUMN id SET DEFAULT nextval('public.game_categories_id_seq'::regclass);


--
-- Name: games id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.games ALTER COLUMN id SET DEFAULT nextval('public.games_id_seq'::regclass);


--
-- Name: hero_images id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.hero_images ALTER COLUMN id SET DEFAULT nextval('public.hero_images_id_seq'::regclass);


--
-- Name: home_ads id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.home_ads ALTER COLUMN id SET DEFAULT nextval('public.home_ads_id_seq'::regclass);


--
-- Name: homepage_content id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.homepage_content ALTER COLUMN id SET DEFAULT nextval('public.homepage_content_id_seq'::regclass);


--
-- Name: password_reset_tokens id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens ALTER COLUMN id SET DEFAULT nextval('public.password_reset_tokens_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: push_campaigns id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.push_campaigns ALTER COLUMN id SET DEFAULT nextval('public.push_campaigns_id_seq'::regclass);


--
-- Name: push_notifications id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.push_notifications ALTER COLUMN id SET DEFAULT nextval('public.push_notifications_id_seq'::regclass);


--
-- Name: push_responses id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.push_responses ALTER COLUMN id SET DEFAULT nextval('public.push_responses_id_seq'::regclass);


--
-- Name: push_subscribers id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.push_subscribers ALTER COLUMN id SET DEFAULT nextval('public.push_subscribers_id_seq'::regclass);


--
-- Name: ratings id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ratings ALTER COLUMN id SET DEFAULT nextval('public.ratings_id_seq'::regclass);


--
-- Name: restores id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.restores ALTER COLUMN id SET DEFAULT nextval('public.restores_id_seq'::regclass);


--
-- Name: role_permissions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.role_permissions ALTER COLUMN id SET DEFAULT nextval('public.role_permissions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: seo_schema_analytics id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.seo_schema_analytics ALTER COLUMN id SET DEFAULT nextval('public.seo_schema_analytics_id_seq'::regclass);


--
-- Name: seo_schema_templates id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.seo_schema_templates ALTER COLUMN id SET DEFAULT nextval('public.seo_schema_templates_id_seq'::regclass);


--
-- Name: seo_schemas id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.seo_schemas ALTER COLUMN id SET DEFAULT nextval('public.seo_schemas_id_seq'::regclass);


--
-- Name: signup_options id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.signup_options ALTER COLUMN id SET DEFAULT nextval('public.signup_options_id_seq'::regclass);


--
-- Name: site_settings id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.site_settings ALTER COLUMN id SET DEFAULT nextval('public.site_settings_id_seq'::regclass);


--
-- Name: sitemaps id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sitemaps ALTER COLUMN id SET DEFAULT nextval('public.sitemaps_id_seq'::regclass);


--
-- Name: static_pages id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.static_pages ALTER COLUMN id SET DEFAULT nextval('public.static_pages_id_seq'::regclass);


--
-- Name: team_members id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.team_members ALTER COLUMN id SET DEFAULT nextval('public.team_members_id_seq'::regclass);


--
-- Name: url_redirects id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.url_redirects ALTER COLUMN id SET DEFAULT nextval('public.url_redirects_id_seq'::regclass);


--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: website_update_history id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.website_update_history ALTER COLUMN id SET DEFAULT nextval('public.website_update_history_id_seq'::regclass);


--
-- Name: website_updates id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.website_updates ALTER COLUMN id SET DEFAULT nextval('public.website_updates_id_seq'::regclass);


--
-- Data for Name: admin_activity_logs; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.admin_activity_logs (id, user_id, action, entity_type, entity_id, description, ip_address, user_agent, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: admin_notifications; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.admin_notifications (id, type, title, message, icon, priority, is_read, action_url, related_entity_type, related_entity_id, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: analytics; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.analytics (id, date, page_views, unique_visitors, game_play_count, average_session_duration, top_games, top_pages) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.api_keys (id, name, type, key, description, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: backup_configs; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.backup_configs (id, name, description, backup_type, storage_location, cloud_storage_path, schedule, is_schedule_enabled, retention_days, max_backups, include_database_structure, include_database_data, include_uploads, include_assets, include_settings, include_logs, compression_enabled, compression_level, is_active, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: backup_files; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.backup_files (id, backup_id, file_path, file_name, file_type, file_size, checksum_md5, last_modified, created_at) FROM stdin;
\.


--
-- Data for Name: backup_logs; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.backup_logs (id, backup_id, restore_id, operation, level, message, details, created_at) FROM stdin;
\.


--
-- Data for Name: backups; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.backups (id, config_id, name, description, backup_type, status, file_name, file_path, cloud_storage_path, file_size, checksum_md5, checksum_sha256, database_table_count, total_records, file_count, started_at, completed_at, duration, error_message, warning_message, metadata, triggered_by, created_by, created_at, updated_at) FROM stdin;
1	\N	MAB-2025-08-28T10-20-35-804Z	mab	full	in_progress	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 10:20:35.804	\N	\N	\N	\N	\N	manual	1	2025-08-28 10:20:35.938774	2025-08-28 10:20:35.938774
\.


--
-- Data for Name: blog_categories; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.blog_categories (id, name, slug, created_at) FROM stdin;
1	Game Reviews	game-reviews	2025-08-28 09:21:21.940913
2	Gaming News	gaming-news	2025-08-28 09:21:21.978352
3	Tips & Tricks	tips-tricks	2025-08-28 09:21:22.015052
4	Development	development	2025-08-28 09:21:22.051694
\.


--
-- Data for Name: blog_posts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.blog_posts (id, title, slug, content, excerpt, featured_image, category_id, tags, status, author, author_avatar, published_at, created_at, updated_at) FROM stdin;
1	Top 10 Games of 2025	top-10-games-of-2025	Here are our picks for the top 10 games released so far in 2025...	Discover the best games released in 2025 so far!	https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&h=500&q=80	1	{games,top10,2025}	published	Admin	https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&q=80	2025-08-28 09:21:22.107	2025-08-28 09:21:22.125502	2025-08-28 09:21:22.125502
2	How to Master 'Zombie Survival'	how-to-master-zombie-survival	Follow these expert tips to survive longer in Zombie Survival game...	Expert strategies to help you survive the zombie apocalypse longer.	https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=800&h=500&q=80	3	{zombie,survival,tips}	published	GameMaster	https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=100&h=100&q=80	2025-08-28 09:21:22.146	2025-08-28 09:21:22.165044	2025-08-28 09:21:22.165044
3	Indie Game Development: Getting Started	indie-game-development-getting-started	Learn how to start developing your own indie games with these beginner-friendly tools...	Your guide to beginning indie game development.	https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&h=500&q=80	4	{development,indie,gamedev}	published	DevGuru	https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=100&h=100&q=80	2025-08-28 09:21:22.183	2025-08-28 09:21:22.202362	2025-08-28 09:21:22.202362
\.


--
-- Data for Name: event_categories; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.event_categories (id, name, slug, description, color, icon, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: event_category_relations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.event_category_relations (id, event_id, category_id, created_at) FROM stdin;
\.


--
-- Data for Name: event_registrations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.event_registrations (id, event_id, user_id, guest_name, guest_email, guest_phone, status, notes, payment_status, registered_at, updated_at) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.events (id, title, slug, description, event_type, status, start_date, end_date, timezone, location_type, location_name, location_address, online_url, registration_enabled, registration_start_date, registration_end_date, max_participants, current_participants, registration_fee, banner_image, gallery, rules, prizes, requirements, contact_info, meta_title, meta_description, featured, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: game_ads; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.game_ads (id, name, "position", ad_code, status, image_url, target_url, start_date, end_date, is_google_ad, ad_enabled, click_count, impression_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: game_categories; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.game_categories (id, name, slug, description, icon, display_order, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: games; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.games (id, title, slug, description, thumbnail, url, api_id, category, category_id, tags, source, status, plays, rating_sum, rating_count, file_type, file_path, file_size, orientation, instructions, screenshot1, screenshot2, screenshot3, screenshot4, app_store_url, play_store_url, amazon_app_store_url, created_at, updated_at) FROM stdin;
1	Space Adventure	space-adventure	Explore the vastness of space in this exciting adventure game.	https://images.unsplash.com/photo-1581822261290-991b38693823?w=500&h=350&q=80	https://example.com/games/space-adventure	\N	Adventure	\N	{space,adventure,exploration}	custom	featured	1250	47	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:20.768505	2025-08-28 09:21:20.768505
2	Zombie Survival	zombie-survival	Survive in a post-apocalyptic world filled with zombies.	https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=500&h=350&q=80	https://example.com/games/zombie-survival	\N	Action	\N	{zombie,survival,horror}	custom	featured	980	45	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:20.808888	2025-08-28 09:21:20.808888
3	Puzzle Master	puzzle-master	Challenge your brain with increasingly difficult puzzles.	https://images.unsplash.com/photo-1553481187-be93c21490a9?w=500&h=350&q=80	https://example.com/games/puzzle-master	\N	Puzzle	\N	{puzzle,brain,challenge}	custom	featured	850	48	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:20.84717	2025-08-28 09:21:20.84717
4	Mystical Quest	mystical-quest	Journey through an enchanted world solving ancient mysteries.	https://images.unsplash.com/photo-1520209759809-a9bcb6cb3241?w=500&h=350&q=80	https://example.com/games/mystical-quest	\N	Adventure	\N	{magic,mystery,puzzle}	custom	featured	1320	46	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:20.883384	2025-08-28 09:21:20.883384
5	Dungeon Crawler	dungeon-crawler	Explore dark dungeons, defeat monsters, and collect treasure.	https://images.unsplash.com/photo-1626750950189-eaa6226a9164?w=500&h=350&q=80	https://example.com/games/dungeon-crawler	\N	RPG	\N	{dungeon,rpg,fantasy}	custom	featured	1470	45	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:20.920931	2025-08-28 09:21:20.920931
6	Cyberpunk Racer	cyberpunk-racer	High-speed racing in a futuristic cyberpunk city.	https://images.unsplash.com/photo-1534370242648-8a3e87adebf8?w=500&h=350&q=80	https://example.com/games/cyberpunk-racer	\N	Racing	\N	{racing,future,cyberpunk}	custom	featured	1620	47	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:20.958971	2025-08-28 09:21:20.958971
7	Tactical Combat	tactical-combat	Lead your squad in tactical turn-based combat operations.	https://images.unsplash.com/photo-1603570724750-88bf70227c9c?w=500&h=350&q=80	https://example.com/games/tactical-combat	\N	Strategy	\N	{strategy,tactical,turn-based}	custom	featured	1150	46	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:20.99626	2025-08-28 09:21:20.99626
8	Athletic Championship	athletic-championship	Compete in various athletic events to win gold medals.	https://images.unsplash.com/photo-1587280501635-68a0e82cd5ff?w=500&h=350&q=80	https://example.com/games/athletic-championship	\N	Sports	\N	{sports,athletics,competition}	custom	featured	940	44	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.032401	2025-08-28 09:21:21.032401
9	Word Master	word-master	Show off your vocabulary and spelling skills.	https://images.unsplash.com/photo-1632580209569-64da0153c5e5?w=500&h=350&q=80	https://example.com/games/word-master	\N	Puzzle	\N	{word,language,education}	custom	featured	1280	43	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.070134	2025-08-28 09:21:21.070134
10	Shadow Ninja	shadow-ninja	Stealthily navigate through enemy territories as a master ninja.	https://images.unsplash.com/photo-1578645561141-dcfabfbfd8b5?w=500&h=350&q=80	https://example.com/games/shadow-ninja	\N	Action	\N	{stealth,ninja,action}	custom	featured	1540	49	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.108001	2025-08-28 09:21:21.108001
11	Racing Champions	racing-champions	Race against opponents on challenging tracks around the world.	https://images.unsplash.com/photo-1547949003-9792a18a2601?w=500&h=350&q=80	https://example.com/games/racing-champions	\N	Racing	\N	{racing,cars,speed}	custom	active	2750	43	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.153713	2025-08-28 09:21:21.153713
12	Fantasy Quest	fantasy-quest	Embark on an epic quest in a magical fantasy world.	https://images.unsplash.com/photo-1542751371-adc38448a05e?w=500&h=350&q=80	https://example.com/games/fantasy-quest	\N	RPG	\N	{fantasy,rpg,adventure}	custom	active	2620	46	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.192546	2025-08-28 09:21:21.192546
13	Sports Legends	sports-legends	Compete in various sports competitions to become a legend.	https://images.unsplash.com/photo-1556056504-5c7696c4c28d?w=500&h=350&q=80	https://example.com/games/sports-legends	\N	Sports	\N	{sports,competition,multiplayer}	custom	active	2580	42	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.239434	2025-08-28 09:21:21.239434
14	Strategy Empire	strategy-empire	Build and expand your empire with strategic decisions.	https://images.unsplash.com/photo-1528155124528-06c125d81e89?w=500&h=350&q=80	https://example.com/games/strategy-empire	\N	Strategy	\N	{strategy,empire,building}	custom	active	2490	44	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.276436	2025-08-28 09:21:21.276436
15	Platformer Pro	platformer-pro	Jump and run through challenging platform levels.	https://images.unsplash.com/photo-1569701813229-33284b643e3c?w=500&h=350&q=80	https://example.com/games/platformer-pro	\N	Platformer	\N	{platformer,jumping,retro}	custom	active	2420	45	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.313625	2025-08-28 09:21:21.313625
16	Cosmic Defenders	cosmic-defenders	Defend your space station against waves of alien invaders.	https://images.unsplash.com/photo-1614032686163-bdc24c13d0b6?w=500&h=350&q=80	https://example.com/games/cosmic-defenders	\N	Action	\N	{space,shooter,arcade}	custom	active	2360	41	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.350852	2025-08-28 09:21:21.350852
17	Treasure Hunter	treasure-hunter	Search for hidden treasures in ancient temples and ruins.	https://images.unsplash.com/photo-1531565637446-32307b194362?w=500&h=350&q=80	https://example.com/games/treasure-hunter	\N	Adventure	\N	{exploration,treasure,archaeology}	custom	active	2280	47	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.388035	2025-08-28 09:21:21.388035
18	Sudoku Challenge	sudoku-challenge	Test your logic skills with various difficulty levels of Sudoku.	https://images.unsplash.com/photo-1580541832626-2a7131ee809f?w=500&h=350&q=80	https://example.com/games/sudoku-challenge	\N	Puzzle	\N	{sudoku,numbers,logic}	custom	active	2150	43	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.42524	2025-08-28 09:21:21.42524
19	Football Manager	football-manager	Manage your own football team, train players, and win championships.	https://images.unsplash.com/photo-1543351611-58f69d7c1781?w=500&h=350&q=80	https://example.com/games/football-manager	\N	Sports	\N	{football,management,strategy}	custom	active	2090	44	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.461457	2025-08-28 09:21:21.461457
20	Monster Hunter	monster-hunter	Track and hunt legendary monsters in a vast open world.	https://images.unsplash.com/photo-1564874954014-d67fda465332?w=500&h=350&q=80	https://example.com/games/monster-hunter	\N	RPG	\N	{hunting,monsters,adventure}	custom	active	1980	48	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.498285	2025-08-28 09:21:21.498285
21	City Builder	city-builder	Design and build your dream city from the ground up.	https://images.unsplash.com/photo-1517649763962-0c623066013b?w=500&h=350&q=80	https://example.com/games/city-builder	\N	Strategy	\N	{building,simulation,management}	custom	active	1940	45	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.534442	2025-08-28 09:21:21.534442
22	Drift King	drift-king	Master the art of drifting in various exotic locations.	https://images.unsplash.com/photo-1526231761088-6d2847588660?w=500&h=350&q=80	https://example.com/games/drift-king	\N	Racing	\N	{drifting,cars,skills}	custom	active	1870	42	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.571624	2025-08-28 09:21:21.571624
23	Rhythm Master	rhythm-master	Test your rhythm and timing with this music-based game.	https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&h=350&q=80	https://example.com/games/rhythm-master	\N	Music	\N	{rhythm,music,timing}	custom	active	1820	46	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.607414	2025-08-28 09:21:21.607414
24	Sniper Elite	sniper-elite	Take down targets with precision from long distances.	https://images.unsplash.com/photo-1608408843758-5a2352902e3f?w=500&h=350&q=80	https://example.com/games/sniper-elite	\N	Action	\N	{shooter,stealth,precision}	custom	active	1790	43	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.646312	2025-08-28 09:21:21.646312
25	Cooking Simulator	cooking-simulator	Prepare delicious meals and manage your own virtual restaurant.	https://images.unsplash.com/photo-1556911220-e15b29be8c8f?w=500&h=350&q=80	https://example.com/games/cooking-simulator	\N	Simulation	\N	{cooking,restaurant,simulation}	custom	active	1730	41	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.682445	2025-08-28 09:21:21.682445
26	Escape Room	escape-room	Solve puzzles to escape from challenging locked rooms.	https://images.unsplash.com/photo-1588196749597-9ff075ee6b5b?w=500&h=350&q=80	https://example.com/games/escape-room	\N	Puzzle	\N	{escape,mystery,logic}	custom	active	1680	47	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.719329	2025-08-28 09:21:21.719329
27	Space Colony	space-colony	Build and manage a colony on a distant planet.	https://images.unsplash.com/photo-1501862700950-18382cd41497?w=500&h=350&q=80	https://example.com/games/space-colony	\N	Strategy	\N	{space,colony,management}	custom	active	1640	44	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.756444	2025-08-28 09:21:21.756444
28	Basketball Legends	basketball-legends	Compete in basketball tournaments with legendary players.	https://images.unsplash.com/photo-1519861531473-9200262188bf?w=500&h=350&q=80	https://example.com/games/basketball-legends	\N	Sports	\N	{basketball,sports,legends}	custom	active	1590	42	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.793584	2025-08-28 09:21:21.793584
29	Retro Pixel Adventure	retro-pixel-adventure	Explore a world of pixel art in this retro-styled adventure.	https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=500&h=350&q=80	https://example.com/games/pixel-adventure	\N	Adventure	\N	{pixel,retro,2D}	custom	active	1540	45	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.829412	2025-08-28 09:21:21.829412
30	Medieval Kingdom	medieval-kingdom	Rule your medieval kingdom and expand your territory.	https://images.unsplash.com/photo-1618336753974-aae8e04506aa?w=500&h=350&q=80	https://example.com/games/medieval-kingdom	\N	Strategy	\N	{medieval,kingdom,strategy}	custom	active	1510	43	10	\N	\N	\N	landscape	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-28 09:21:21.865576	2025-08-28 09:21:21.865576
\.


--
-- Data for Name: hero_images; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.hero_images (id, title, description, image_path, link_url, link_text, is_active, sort_order, display_duration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: home_ads; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.home_ads (id, name, "position", ad_code, status, image_url, target_url, start_date, end_date, is_google_ad, ad_enabled, click_count, impression_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: homepage_content; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.homepage_content (id, title, content, "position", status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.password_reset_tokens (id, user_id, token, token_hash, type, used_at, ip_address, user_agent, is_admin, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.permissions (id, resource, action, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: push_campaigns; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.push_campaigns (id, name, title, message, image, link, action_yes, action_no, notification_type, is_web_push, require_interaction, badge, icon, vibrate, is_survey, target_all, target_filters, sent_count, delivered_count, click_count, schedule_date, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: push_notifications; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.push_notifications (id, title, message, image, link, type, active, click_count, impression_count, created_at, updated_at) FROM stdin;
1	Welcome to GameZone!	Thanks for visiting our gaming website. Check out our featured games!	\N	/games/featured	toast	t	0	0	2025-08-28 09:21:22.278081	2025-08-28 09:21:22.278081
2	New Games Added!	Check out the latest games we've added to our platform.	\N	/games/new	banner	t	0	0	2025-08-28 09:21:22.315963	2025-08-28 09:21:22.315963
\.


--
-- Data for Name: push_responses; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.push_responses (id, campaign_id, subscriber_id, response, clicked, created_at) FROM stdin;
\.


--
-- Data for Name: push_subscribers; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.push_subscribers (id, endpoint, p256dh, auth, user_agent, browser, os, device_type, country, region, city, last_sent, status, web_push_enabled, notification_permission, preferred_types, frequency_limit, opt_in_date, last_interacted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ratings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.ratings (id, game_id, rating, created_at) FROM stdin;
\.


--
-- Data for Name: restores; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.restores (id, backup_id, name, description, status, restore_database, restore_files, restore_settings, create_backup_before_restore, pre_restore_backup_id, started_at, completed_at, duration, total_steps, completed_steps, current_step, tables_restored, records_restored, files_restored, error_message, warning_message, metadata, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.role_permissions (id, role_id, permission_id, created_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.roles (id, name, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: seo_schema_analytics; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.seo_schema_analytics (id, schema_id, date, impressions, clicks, avg_position, rich_snippet_appearances, validation_status, created_at) FROM stdin;
\.


--
-- Data for Name: seo_schema_templates; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.seo_schema_templates (id, name, schema_type, content_type, template, description, is_default, is_active, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: seo_schemas; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.seo_schemas (id, schema_type, content_type, content_id, name, schema_data, is_active, is_auto_generated, last_validated, validation_errors, priority, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.session (sid, sess, expire) FROM stdin;
c4GrvQlg6I6oNkmK05RQSMHv4K6KrQut	{"cookie":{"originalMaxAge":604800000,"expires":"2025-09-04T09:28:05.059Z","secure":false,"httpOnly":true,"path":"/","sameSite":"strict"},"passport":{"user":1}}	2025-09-04 09:28:06
GHwLiy3RtMMrbOlNFha6ThVK51koTAYm	{"cookie":{"originalMaxAge":604800000,"expires":"2025-09-04T09:34:36.511Z","secure":false,"httpOnly":true,"path":"/","sameSite":"strict"},"passport":{"user":1}}	2025-09-04 09:34:37
U9WlKkPVNbFlACZcTtd9DqkS4ERwbKrY	{"cookie":{"originalMaxAge":604800000,"expires":"2025-09-04T09:36:27.718Z","secure":false,"httpOnly":true,"path":"/","sameSite":"strict"},"passport":{"user":1}}	2025-09-04 10:20:01
\.


--
-- Data for Name: signup_options; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.signup_options (id, provider, display_name, is_enabled, icon, color, sort_order, configuration, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.site_settings (id, site_title, meta_description, keywords, site_logo, site_favicon, use_text_logo, text_logo_color, current_theme, ads_txt, footer_copyright, footer_app_store_link, footer_google_play_link, footer_amazon_link, social_facebook, social_twitter, social_instagram, social_youtube, social_discord, social_whatsapp, social_tiktok, header_ads, footer_ads, sidebar_ads, content_ads, floating_header_ads, floating_footer_ads, paragraph2_ad, paragraph4_ad, paragraph6_ad, paragraph8_ad, after_content_ad, enable_google_ads, google_ad_client, push_notifications_enabled, blog_games_enabled, paragraph2_games_enabled, paragraph6_games_enabled, paragraph8_games_enabled, paragraph10_games_enabled, custom_header_code, custom_body_code, custom_footer_code, robots_txt, cookie_popup_enabled, cookie_popup_title, cookie_popup_message, cookie_accept_button_text, cookie_decline_button_text, cookie_learn_more_text, cookie_learn_more_url, cookie_popup_position, cookie_popup_theme, updated_at) FROM stdin;
\.


--
-- Data for Name: sitemaps; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.sitemaps (id, type, last_generated, url, item_count, content, is_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: static_pages; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.static_pages (id, title, slug, content, page_type, meta_title, meta_description, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.team_members (id, name, designation, profile_picture, bio, social_linkedin, social_twitter, social_github, social_instagram, social_tiktok, social_facebook, social_youtube, display_order, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: url_redirects; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.url_redirects (id, source_url, target_url, status_code, is_active, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.user_sessions (id, user_id, token, ip_address, user_agent, device_info, last_activity, expires_at, status, location, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, username, email, password, is_admin, role_id, display_name, profile_picture, bio, country, account_type, social_id, status, last_login, location, created_at, updated_at) FROM stdin;
1	admin	\N	5ea1387deaf58e307d4b06495305f6e22a32e7ae4009eeb22ea81bf00b14579ecf13ab9f502701ed0b24a6b7f41d1f709c68aca6aa983d85827398ccac04a83a.8952071199b2465c8398c52813d1944d	t	\N	\N	\N	\N	\N	local	\N	active	2025-08-28 09:36:27.568	\N	2025-08-28 09:21:20.686527	2025-08-28 09:21:20.686527
\.


--
-- Data for Name: website_update_history; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.website_update_history (id, update_id, version, title, description, change_type, priority, status, github_commit_hash, deployment_url, rollback_data, is_active, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: website_updates; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.website_updates (id, title, description, version, change_type, priority, status, deployment_url, github_commit_hash, scheduled_at, deployed_at, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Name: admin_activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.admin_activity_logs_id_seq', 1, false);


--
-- Name: admin_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.admin_notifications_id_seq', 1, false);


--
-- Name: analytics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.analytics_id_seq', 1, false);


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 1, false);


--
-- Name: backup_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.backup_configs_id_seq', 1, false);


--
-- Name: backup_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.backup_files_id_seq', 1, false);


--
-- Name: backup_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.backup_logs_id_seq', 1, false);


--
-- Name: backups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.backups_id_seq', 1, true);


--
-- Name: blog_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.blog_categories_id_seq', 4, true);


--
-- Name: blog_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.blog_posts_id_seq', 3, true);


--
-- Name: event_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.event_categories_id_seq', 1, false);


--
-- Name: event_category_relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.event_category_relations_id_seq', 1, false);


--
-- Name: event_registrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.event_registrations_id_seq', 1, false);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.events_id_seq', 1, false);


--
-- Name: game_ads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.game_ads_id_seq', 1, false);


--
-- Name: game_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.game_categories_id_seq', 1, false);


--
-- Name: games_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.games_id_seq', 30, true);


--
-- Name: hero_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.hero_images_id_seq', 1, false);


--
-- Name: home_ads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.home_ads_id_seq', 1, false);


--
-- Name: homepage_content_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.homepage_content_id_seq', 1, false);


--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.password_reset_tokens_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.permissions_id_seq', 1, false);


--
-- Name: push_campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.push_campaigns_id_seq', 1, false);


--
-- Name: push_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.push_notifications_id_seq', 2, true);


--
-- Name: push_responses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.push_responses_id_seq', 1, false);


--
-- Name: push_subscribers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.push_subscribers_id_seq', 1, false);


--
-- Name: ratings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.ratings_id_seq', 1, false);


--
-- Name: restores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.restores_id_seq', 1, false);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.role_permissions_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, false);


--
-- Name: seo_schema_analytics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.seo_schema_analytics_id_seq', 1, false);


--
-- Name: seo_schema_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.seo_schema_templates_id_seq', 1, false);


--
-- Name: seo_schemas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.seo_schemas_id_seq', 1, false);


--
-- Name: signup_options_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.signup_options_id_seq', 1, false);


--
-- Name: site_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.site_settings_id_seq', 1, false);


--
-- Name: sitemaps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.sitemaps_id_seq', 1, false);


--
-- Name: static_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.static_pages_id_seq', 1, false);


--
-- Name: team_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.team_members_id_seq', 1, false);


--
-- Name: url_redirects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.url_redirects_id_seq', 1, false);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.user_sessions_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: website_update_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.website_update_history_id_seq', 1, false);


--
-- Name: website_updates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.website_updates_id_seq', 1, false);


--
-- Name: admin_activity_logs admin_activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.admin_activity_logs
    ADD CONSTRAINT admin_activity_logs_pkey PRIMARY KEY (id);


--
-- Name: admin_notifications admin_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.admin_notifications
    ADD CONSTRAINT admin_notifications_pkey PRIMARY KEY (id);


--
-- Name: analytics analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.analytics
    ADD CONSTRAINT analytics_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: backup_configs backup_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.backup_configs
    ADD CONSTRAINT backup_configs_pkey PRIMARY KEY (id);


--
-- Name: backup_files backup_files_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.backup_files
    ADD CONSTRAINT backup_files_pkey PRIMARY KEY (id);


--
-- Name: backup_logs backup_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT backup_logs_pkey PRIMARY KEY (id);


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: blog_categories blog_categories_name_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_categories
    ADD CONSTRAINT blog_categories_name_unique UNIQUE (name);


--
-- Name: blog_categories blog_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_categories
    ADD CONSTRAINT blog_categories_pkey PRIMARY KEY (id);


--
-- Name: blog_categories blog_categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_categories
    ADD CONSTRAINT blog_categories_slug_unique UNIQUE (slug);


--
-- Name: blog_posts blog_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_slug_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_slug_unique UNIQUE (slug);


--
-- Name: event_categories event_categories_name_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.event_categories
    ADD CONSTRAINT event_categories_name_unique UNIQUE (name);


--
-- Name: event_categories event_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.event_categories
    ADD CONSTRAINT event_categories_pkey PRIMARY KEY (id);


--
-- Name: event_categories event_categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.event_categories
    ADD CONSTRAINT event_categories_slug_unique UNIQUE (slug);


--
-- Name: event_category_relations event_category_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.event_category_relations
    ADD CONSTRAINT event_category_relations_pkey PRIMARY KEY (id);


--
-- Name: event_registrations event_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.event_registrations
    ADD CONSTRAINT event_registrations_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: events events_slug_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_slug_unique UNIQUE (slug);


--
-- Name: game_ads game_ads_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.game_ads
    ADD CONSTRAINT game_ads_pkey PRIMARY KEY (id);


--
-- Name: game_categories game_categories_name_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.game_categories
    ADD CONSTRAINT game_categories_name_unique UNIQUE (name);


--
-- Name: game_categories game_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.game_categories
    ADD CONSTRAINT game_categories_pkey PRIMARY KEY (id);


--
-- Name: game_categories game_categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.game_categories
    ADD CONSTRAINT game_categories_slug_unique UNIQUE (slug);


--
-- Name: games games_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT games_pkey PRIMARY KEY (id);


--
-- Name: games games_slug_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT games_slug_unique UNIQUE (slug);


--
-- Name: hero_images hero_images_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.hero_images
    ADD CONSTRAINT hero_images_pkey PRIMARY KEY (id);


--
-- Name: home_ads home_ads_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.home_ads
    ADD CONSTRAINT home_ads_pkey PRIMARY KEY (id);


--
-- Name: homepage_content homepage_content_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.homepage_content
    ADD CONSTRAINT homepage_content_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_unique UNIQUE (token);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: push_campaigns push_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.push_campaigns
    ADD CONSTRAINT push_campaigns_pkey PRIMARY KEY (id);


--
-- Name: push_notifications push_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.push_notifications
    ADD CONSTRAINT push_notifications_pkey PRIMARY KEY (id);


--
-- Name: push_responses push_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.push_responses
    ADD CONSTRAINT push_responses_pkey PRIMARY KEY (id);


--
-- Name: push_subscribers push_subscribers_endpoint_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.push_subscribers
    ADD CONSTRAINT push_subscribers_endpoint_unique UNIQUE (endpoint);


--
-- Name: push_subscribers push_subscribers_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.push_subscribers
    ADD CONSTRAINT push_subscribers_pkey PRIMARY KEY (id);


--
-- Name: ratings ratings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_pkey PRIMARY KEY (id);


--
-- Name: restores restores_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.restores
    ADD CONSTRAINT restores_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_unique UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: seo_schema_analytics seo_schema_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.seo_schema_analytics
    ADD CONSTRAINT seo_schema_analytics_pkey PRIMARY KEY (id);


--
-- Name: seo_schema_templates seo_schema_templates_name_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.seo_schema_templates
    ADD CONSTRAINT seo_schema_templates_name_unique UNIQUE (name);


--
-- Name: seo_schema_templates seo_schema_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.seo_schema_templates
    ADD CONSTRAINT seo_schema_templates_pkey PRIMARY KEY (id);


--
-- Name: seo_schemas seo_schemas_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.seo_schemas
    ADD CONSTRAINT seo_schemas_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: signup_options signup_options_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.signup_options
    ADD CONSTRAINT signup_options_pkey PRIMARY KEY (id);


--
-- Name: signup_options signup_options_provider_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.signup_options
    ADD CONSTRAINT signup_options_provider_unique UNIQUE (provider);


--
-- Name: site_settings site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- Name: sitemaps sitemaps_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sitemaps
    ADD CONSTRAINT sitemaps_pkey PRIMARY KEY (id);


--
-- Name: static_pages static_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.static_pages
    ADD CONSTRAINT static_pages_pkey PRIMARY KEY (id);


--
-- Name: static_pages static_pages_slug_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.static_pages
    ADD CONSTRAINT static_pages_slug_unique UNIQUE (slug);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (id);


--
-- Name: url_redirects url_redirects_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.url_redirects
    ADD CONSTRAINT url_redirects_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: website_update_history website_update_history_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.website_update_history
    ADD CONSTRAINT website_update_history_pkey PRIMARY KEY (id);


--
-- Name: website_updates website_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.website_updates
    ADD CONSTRAINT website_updates_pkey PRIMARY KEY (id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- Name: event_category_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX event_category_idx ON public.event_category_relations USING btree (event_id, category_id);


--
-- Name: event_guest_email_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX event_guest_email_idx ON public.event_registrations USING btree (event_id, guest_email);


--
-- Name: event_user_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX event_user_idx ON public.event_registrations USING btree (event_id, user_id);


--
-- Name: resource_action_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX resource_action_idx ON public.permissions USING btree (resource, action);


--
-- Name: role_permission_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX role_permission_idx ON public.role_permissions USING btree (role_id, permission_id);


--
-- Name: admin_activity_logs admin_activity_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.admin_activity_logs
    ADD CONSTRAINT admin_activity_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: admin_notifications admin_notifications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.admin_notifications
    ADD CONSTRAINT admin_notifications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: backup_configs backup_configs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.backup_configs
    ADD CONSTRAINT backup_configs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: backup_files backup_files_backup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.backup_files
    ADD CONSTRAINT backup_files_backup_id_fkey FOREIGN KEY (backup_id) REFERENCES public.backups(id) ON DELETE CASCADE;


--
-- Name: backup_logs backup_logs_backup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT backup_logs_backup_id_fkey FOREIGN KEY (backup_id) REFERENCES public.backups(id) ON DELETE CASCADE;


--
-- Name: backup_logs backup_logs_restore_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT backup_logs_restore_id_fkey FOREIGN KEY (restore_id) REFERENCES public.restores(id) ON DELETE CASCADE;


--
-- Name: backups backups_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_config_id_fkey FOREIGN KEY (config_id) REFERENCES public.backup_configs(id) ON DELETE SET NULL;


--
-- Name: backups backups_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: blog_posts blog_posts_category_id_blog_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_category_id_blog_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.blog_categories(id);


--
-- Name: event_category_relations event_category_relations_category_id_event_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.event_category_relations
    ADD CONSTRAINT event_category_relations_category_id_event_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.event_categories(id) ON DELETE CASCADE;


--
-- Name: event_category_relations event_category_relations_event_id_events_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.event_category_relations
    ADD CONSTRAINT event_category_relations_event_id_events_id_fk FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: event_registrations event_registrations_event_id_events_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.event_registrations
    ADD CONSTRAINT event_registrations_event_id_events_id_fk FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: event_registrations event_registrations_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.event_registrations
    ADD CONSTRAINT event_registrations_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: events events_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: games games_category_id_game_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT games_category_id_game_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.game_categories(id);


--
-- Name: password_reset_tokens password_reset_tokens_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: push_responses push_responses_campaign_id_push_campaigns_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.push_responses
    ADD CONSTRAINT push_responses_campaign_id_push_campaigns_id_fk FOREIGN KEY (campaign_id) REFERENCES public.push_campaigns(id);


--
-- Name: push_responses push_responses_subscriber_id_push_subscribers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.push_responses
    ADD CONSTRAINT push_responses_subscriber_id_push_subscribers_id_fk FOREIGN KEY (subscriber_id) REFERENCES public.push_subscribers(id);


--
-- Name: ratings ratings_game_id_games_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_game_id_games_id_fk FOREIGN KEY (game_id) REFERENCES public.games(id);


--
-- Name: restores restores_backup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.restores
    ADD CONSTRAINT restores_backup_id_fkey FOREIGN KEY (backup_id) REFERENCES public.backups(id);


--
-- Name: restores restores_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.restores
    ADD CONSTRAINT restores_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: restores restores_pre_restore_backup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.restores
    ADD CONSTRAINT restores_pre_restore_backup_id_fkey FOREIGN KEY (pre_restore_backup_id) REFERENCES public.backups(id);


--
-- Name: role_permissions role_permissions_permission_id_permissions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_permissions_id_fk FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_roles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_roles_id_fk FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: seo_schema_analytics seo_schema_analytics_schema_id_seo_schemas_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.seo_schema_analytics
    ADD CONSTRAINT seo_schema_analytics_schema_id_seo_schemas_id_fk FOREIGN KEY (schema_id) REFERENCES public.seo_schemas(id) ON DELETE CASCADE;


--
-- Name: seo_schema_templates seo_schema_templates_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.seo_schema_templates
    ADD CONSTRAINT seo_schema_templates_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: seo_schema_templates seo_schema_templates_updated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.seo_schema_templates
    ADD CONSTRAINT seo_schema_templates_updated_by_users_id_fk FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: seo_schemas seo_schemas_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.seo_schemas
    ADD CONSTRAINT seo_schemas_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: seo_schemas seo_schemas_updated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.seo_schemas
    ADD CONSTRAINT seo_schemas_updated_by_users_id_fk FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: user_sessions user_sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_role_id_roles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_roles_id_fk FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: website_update_history website_update_history_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.website_update_history
    ADD CONSTRAINT website_update_history_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: website_update_history website_update_history_update_id_website_updates_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.website_update_history
    ADD CONSTRAINT website_update_history_update_id_website_updates_id_fk FOREIGN KEY (update_id) REFERENCES public.website_updates(id);


--
-- Name: website_updates website_updates_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.website_updates
    ADD CONSTRAINT website_updates_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: DATABASE neondb; Type: ACL; Schema: -; Owner: neondb_owner
--

GRANT ALL ON DATABASE neondb TO neon_superuser;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

